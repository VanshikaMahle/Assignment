import React from "react";

export default function error() {
  return (
    <>
    <div className="header2">
        <p>Popular Titles</p>
    </div>
    <div className='container'> 
      <h4>oops, Something went wrong..........</h4>
    </div>
    </>
  ); 
}