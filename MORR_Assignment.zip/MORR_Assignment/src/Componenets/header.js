import React from 'react'
import './header.css'

export default function header() {
    return (
        <div>
            <div className="header1">
                <p>DEMO Streaming</p>
                <div className="btn">
                    <a href="">Login</a>
                    <button>Start your free link</button>
                </div>
            </div>
            
            
        </div>
    )
}
